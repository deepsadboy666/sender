<?php
require_once "settings.php";
goto oFurg;
gbhqC:
$no_send = 1;
goto W2Fgy;
YCJYb:
foreach ($mailist_split as $key => $list) {
    $grabsmtps = $smtp[$i % count($smtp)];
    $grabsmtp = explode(",", $grabsmtps);
    $sendmail = AbstergoSend(
        $list,
        $grabsmtps,
        $abstergo_config,
        $abstergo_send
    );
    if ($sendmail["status"] == "success") {
        $sendstatus = c(
            $g,
            "[SUCCESS]
",
            $m
        );
    } else {
        $sendstatus = c(
            $r,
            "[FAILED] REASON > " .
                $sendmail["info"] .
                "

",
            $m
        );
    }
    echo "
" .
        c($y, "      SENDING " . $no_send . " / " . count($mailist_split), $m) .
        "
";
    foreach ($list as $keys => $added) {
        echo "" .
            c($b, "      > SENT TO :", $m) .
            " " .
            c($c, strtoupper($added), $m) .
            "
";
        echo "" .
            c($b, "      > BY SMTP :", $m) .
            " " .
            c($g, strtoupper($grabsmtp[0]), $m) .
            "
";
        if ($sendmail["from"] != null && $sendmail["subject"] != null) {
            echo "" .
                c($b, "      > FROM    :", $m) .
                " " .
                c($y, $sendmail["from"], $m) .
                "
";
            echo "" .
                c($b, "      > SUBJECT :", $m) .
                " " .
                c($p, $sendmail["subject"], $m) .
                "
";
        }
        echo c($b, "      > STATUS  : ", $m) . $sendstatus;
    }
    $i++;
    $no_send++;
    sleep($abstergo_config["Delay"]);
}
goto GhxYt;
mPaG6:
echo c(
    $c,
    "
      Total Mailist Detected => " . $mailistcount,
    $m
) .
    "
";
goto qAPFN;
N1eHo:
if ($continue != "y") {
    die(
        c($r, "      Sending Aborted!", $m) .
            "
"
    );
}
goto FSs1q;
yvOGs:
$checkaccess = "granted";//checkaccess($accesskey);
goto VWrKa;
hS5Vy:
$g = "green";
goto CLi2H;
NbIT5:
$smtp = array_values(array_filter($smtp));
goto DIBgD;
Vs5Ij:
$mailistcount = count($mailist);
goto mPaG6;
PXU2Y:
$mailist = preg_split(
    "/\n/",
    $mailist
);
goto d_Mug;
IY_jH:
$smtp = preg_split(
    "/\n/",
    $smtp
);
goto NbIT5;
Yd2fy:
$y = "yellow";
goto lz8Mx;
wNYtx:
date_default_timezone_set($abstergo_config["TimeZone"]);
goto mWejW;
W2Fgy:
$no_list = 1;
goto LpeXH;
mrXTK:
if ($abstergo_send["SendTwoTimes"] == true) {
    $newlist = [];
    foreach ($mailist_split as $arraykey => $arrayvalue) {
        array_push($newlist, $arrayvalue);
        array_push($newlist, $arrayvalue);
    }
    $mailist_split = $newlist;
}
goto l0pE4;
LpeXH:
$mailist_split = array_chunk($mailist, $abstergo_config["Connection"]);
goto mrXTK;
kVp5N:
$i = 0;
goto gbhqC;
eprsC:
include "Abstergo/Construct_Main.php";
goto tn9VT;
VWrKa:
if ($checkaccess != "granted") {
    echo "
    " .
        c($b, "==========================================", $m) .
        "
    " .
        c($b, "+", $m) .
        "" .
        c($c, "·····················  ·················", $m) .
        "" .
        c($b, "+", $m) .
        "
    " .
        c($b, "+", $m) .
        "" .
        c($c, "···················· ", $m) .
        "" .
        c($r, "██", $m) .
        "" .
        c($c, " · ", $m) .
        "" .
        c($r, "STATUS: FAIL", $m) .
        "" .
        c($c, " ·", $m) .
        "" .
        c($b, "+", $m) .
        "
    " .
        c($b, "+", $m) .
        "" .
        c($c, "··", $m) .
        "" .
        c($y, " ABSTERGO ID ", $m) .
        "" .
        c($c, "····", $m) .
        "" .
        c($r, " ████ ", $m) .
        "" .
        c($c, "···············", $m) .
        "" .
        c($b, "+", $m) .
        "
    " .
        c($b, "+", $m) .
        "" .
        c($c, "··", $m) .
        "" .
        c($y, " SENDER v1.6 ", $m) .
        "" .
        c($c, "···", $m) .
        "" .
        c($r, " ██████ ", $m) .
        "" .
        c($c, "··············", $m) .
        "" .
        c($b, "+", $m) .
        "
    " .
        c($b, "+", $m) .
        "" .
        c($c, "··", $m) .
        "" .
        c($y, " BUILD 3 ", $m) .
        "·" .
        c($c, "·····", $m) .
        "" .
        c($r, " ████████ ", $m) .
        "" .
        c($c, "·············", $m) .
        "" .
        c($b, "+", $m) .
        "
    " .
        c($b, "+", $m) .
        "" .
        c($c, "··", $m) .
        "" .
        c($y, " BETA ", $m) .
        "" .
        c($c, "········", $m) .
        "" .
        c($r, " ██████████ ", $m) .
        "" .
        c($c, "············", $m) .
        "" .
        c($b, "+", $m) .
        "
    " .
        c($b, "+", $m) .
        "" .
        c($c, "···············", $m) .
        "" .
        c($r, " ██████████ ", $m) .
        "" .
        c($c, "·············", $m) .
        "" .
        c($b, "+", $m) .
        "
    " .
        c($b, "+", $m) .
        "" .
        c($c, "··············", $m) .
        "" .
        c($r, " ██████████  ██ ", $m) .
        "" .
        c($c, "··········", $m) .
        "" .
        c($b, "+", $m) .
        "
    " .
        c($b, "+", $m) .
        "" .
        c($c, "·············", $m) .
        "" .
        c($r, " ██████████  ████ ", $m) .
        "" .
        c($c, "·········", $m) .
        "" .
        c($b, "+", $m) .
        "
    " .
        c($b, "+", $m) .
        "" .
        c($c, "············", $m) .
        "" .
        c($r, " ██████████  ██████ ", $m) .
        "" .
        c($c, "········", $m) .
        "" .
        c($b, "+", $m) .
        "
    " .
        c($b, "+", $m) .
        "" .
        c($c, "···········", $m) .
        "" .
        c($r, " ██████████  ████████ ", $m) .
        "" .
        c($c, "·······", $m) .
        "" .
        c($b, "+", $m) .
        "
    " .
        c($b, "+", $m) .
        "" .
        c($c, "···········", $m) .
        "" .
        c($r, "            ██████████ ", $m) .
        "" .
        c($c, "······", $m) .
        "" .
        c($b, "+", $m) .
        "
    " .
        c($b, "+", $m) .
        "" .
        c($c, "····", $m) .
        "" .
        c($r, " █████████████████  ██████████ ", $m) .
        "" .
        c($c, "·····", $m) .
        "" .
        c($b, "+", $m) .
        "
    " .
        c($b, "+", $m) .
        "" .
        c($c, "···", $m) .
        "" .
        c($r, " ███████████████████  ██████████ ", $m) .
        "" .
        c($c, "····", $m) .
        "" .
        c($b, "+", $m) .
        "
    " .
        c($b, "+", $m) .
        "" .
        c($c, "··", $m) .
        "" .
        c($r, " █████████████████████  ██████████ ", $m) .
        "" .
        c($c, "···", $m) .
        "" .
        c($b, "+", $m) .
        "
    " .
        c($b, "+", $m) .
        "" .
        c($c, "··························", $m) .
        "" .
        c($r, " ██████████ ", $m) .
        "" .
        c($c, "··", $m) .
        "" .
        c($b, "+", $m) .
        "
    " .
        c($b, "+", $m) .
        "" .
        c($c, "········································", $m) .
        "" .
        c($b, "+", $m) .
        "
    " .
        c($b, "==========================================", $m) .
        "
    " .
        c($b, "+", $m) .
        "" .
        c($y, " ABSTERGO.ID ", $m) .
        "" .
        c($c, "···························", $m) .
        "" .
        c($b, "+", $m) .
        "
    " .
        c($b, "+", $m) .
        "" .
        c($y, " T.ME/ABSTERGOID ", $m) .
        "" .
        c($c, "·······················", $m) .
        "" .
        c($b, "+", $m) .
        "
    " .
        c($b, "+", $m) .
        "" .
        c($y, " FB.COM/ABSTERGO.ID ", $m) .
        "" .
        c($c, "····················", $m) .
        "" .
        c($b, "+", $m) .
        "
    " .
        c($b, "==========================================", $m) .
        "
    ";
    die(
        c(
            $r,
            "

   ERROR! REASON : WRONG LICENSE KEY OR DEVICE ID HAS CHANGED!

",
            $m
        )
    );
} else {
    echo "
    " .
        c($b, "  ==========================================", $m) .
        "
    " .
        c($b, "  +", $m) .
        "" .
        c($c, "·····················  ·················", $m) .
        "" .
        c($b, "+", $m) .
        "
    " .
        c($b, "  +", $m) .
        "" .
        c($c, "···················· ", $m) .
        "" .
        c($g, "██", $m) .
        "" .
        c($c, " · ", $m) .
        "" .
        c($g, "STATUS: OK", $m) .
        "" .
        c($c, " ···", $m) .
        "" .
        c($b, "+", $m) .
        "
    " .
        c($b, "  +", $m) .
        "" .
        c($c, "··", $m) .
        "" .
        c($y, " ABSTERGO ID ", $m) .
        "" .
        c($c, "····", $m) .
        "" .
        c($g, " ████ ", $m) .
        "" .
        c($c, "···············", $m) .
        "" .
        c($b, "+", $m) .
        "
    " .
        c($b, "  +", $m) .
        "" .
        c($c, "··", $m) .
        "" .
        c($y, " SENDER v1.6 ", $m) .
        "" .
        c($c, "···", $m) .
        "" .
        c($g, " ██████ ", $m) .
        "" .
        c($c, "··············", $m) .
        "" .
        c($b, "+", $m) .
        "
    " .
        c($b, "  +", $m) .
        "" .
        c($c, "··", $m) .
        "" .
        c($y, " BUILD 3 ", $m) .
        "" .
        c($c, "······", $m) .
        "" .
        c($g, " ████████ ", $m) .
        "" .
        c($c, "·············", $m) .
        "" .
        c($b, "+", $m) .
        "
    " .
        c($b, "  +", $m) .
        "" .
        c($c, "··", $m) .
        "" .
        c($y, " BETA ", $m) .
        "" .
        c($c, "········", $m) .
        "" .
        c($g, " ██████████ ", $m) .
        "" .
        c($c, "············", $m) .
        "" .
        c($b, "+", $m) .
        "
    " .
        c($b, "  +", $m) .
        "" .
        c($c, "···············", $m) .
        "" .
        c($g, " ██████████ ", $m) .
        "" .
        c($c, "·············", $m) .
        "" .
        c($b, "+", $m) .
        "
    " .
        c($b, "  +", $m) .
        "" .
        c($c, "··············", $m) .
        "" .
        c($g, " ██████████  ██ ", $m) .
        "" .
        c($c, "··········", $m) .
        "" .
        c($b, "+", $m) .
        "
    " .
        c($b, "  +", $m) .
        "" .
        c($c, "·············", $m) .
        "" .
        c($g, " ██████████  ████ ", $m) .
        "" .
        c($c, "·········", $m) .
        "" .
        c($b, "+", $m) .
        "
    " .
        c($b, "  +", $m) .
        "" .
        c($c, "············", $m) .
        "" .
        c($g, " ██████████  ██████ ", $m) .
        "" .
        c($c, "········", $m) .
        "" .
        c($b, "+", $m) .
        "
    " .
        c($b, "  +", $m) .
        "" .
        c($c, "···········", $m) .
        "" .
        c($g, " ██████████  ████████ ", $m) .
        "" .
        c($c, "·······", $m) .
        "" .
        c($b, "+", $m) .
        "
    " .
        c($b, "  +", $m) .
        "" .
        c($c, "···········", $m) .
        "" .
        c($g, "            ██████████ ", $m) .
        "" .
        c($c, "······", $m) .
        "" .
        c($b, "+", $m) .
        "
    " .
        c($b, "  +", $m) .
        "" .
        c($c, "····", $m) .
        "" .
        c($g, " █████████████████  ██████████ ", $m) .
        "" .
        c($c, "·····", $m) .
        "" .
        c($b, "+", $m) .
        "
    " .
        c($b, "  +", $m) .
        "" .
        c($c, "···", $m) .
        "" .
        c($g, " ███████████████████  ██████████ ", $m) .
        "" .
        c($c, "····", $m) .
        "" .
        c($b, "+", $m) .
        "
    " .
        c($b, "  +", $m) .
        "" .
        c($c, "··", $m) .
        "" .
        c($g, " █████████████████████  ██████████ ", $m) .
        "" .
        c($c, "···", $m) .
        "" .
        c($b, "+", $m) .
        "
    " .
        c($b, "  +", $m) .
        "" .
        c($c, "··························", $m) .
        "" .
        c($g, " ██████████ ", $m) .
        "" .
        c($c, "··", $m) .
        "" .
        c($b, "+", $m) .
        "
    " .
        c($b, "  +", $m) .
        "" .
        c($c, "········································", $m) .
        "" .
        c($b, "+", $m) .
        "
    " .
        c($b, "  ==========================================", $m) .
        "
    " .
        c($b, "  +", $m) .
        "" .
        c($y, " ABSTERGO.ID ", $m) .
        "" .
        c($c, "···························", $m) .
        "" .
        c($b, "+", $m) .
        "
    " .
        c($b, "  +", $m) .
        "" .
        c($y, " T.ME/ABSTERGOID ", $m) .
        "" .
        c($c, "·······················", $m) .
        "" .
        c($b, "+", $m) .
        "
    " .
        c($b, "  +", $m) .
        "" .
        c($y, " FB.COM/ABSTERGO.ID ", $m) .
        "" .
        c($c, "····················", $m) .
        "" .
        c($b, "+", $m) .
        "
    " .
        c($b, "  ==========================================", $m) .
        "
    ";
}
goto AUK7p;
d_Mug:
if ($abstergo_config["ClearDuplicate"] == true) {
    $mailist = array_unique($mailist);
}
goto LAqA9;
NEva1:
$mailist = preg_grep(
    "/[a-z0-9]+([_\.-][a-z0-9]+)*@([a-z0-9]+([\.-][a-z0-9]+)*)+\.[a-z]{2,}/i",
    $mailist
);
goto Vs5Ij;
ITBRA:
$c = "cyan";
goto Yd2fy;
tn9VT:
require_once "settings.php";
goto wNYtx;
LAqA9:
$mailist = str_replace(" ", "", $mailist);
goto NEva1;
mWejW:
$m = $abstergo_config["ColorMode"];
goto gYgsK;
l0pE4:
if ($abstergo_send["EmailTest"] != null) {
    if ($abstergo_send["TestAfter"] == null) {
        die(
            c($r, "      Test after is empty!", $m) .
                "
"
        );
    } else {
        $mailtest = ["0" => $abstergo_send["EmailTest"]];
        $testafter = $abstergo_send["TestAfter"];
        $mailist_split = array_reduce(
            array_map(function ($i) use ($mailtest, $testafter) {
                return count($i) == $testafter
                    ? array_merge($i, [$mailtest])
                    : $i;
            }, array_chunk($mailist_split, $testafter)),
            function ($r, $i) {
                return array_merge($r, $i);
            },
            []
        );
    }
}
goto YCJYb;
lz8Mx:
$accesskey = file_get_contents("license.ini");
goto yvOGs;
LGwJy:
require_once "Modules/Function.php";
goto eprsC;
DIBgD:
$no = 1;
goto kVp5N;
gYgsK:
$r = "red";
goto hS5Vy;
TTyWq:
$p = "purple";
goto ITBRA;
CLi2H:
$b = "blue";
goto TTyWq;
FSs1q:
($smtp = file_get_contents("Smtp/" . $abstergo_config["SMTPFile"])) or
    die("   SMTP Not Found!");
goto IY_jH;
oFurg:
error_reporting(E_ALL);
goto LGwJy;
qAPFN:
$continue = scrn("      Continue Sending ? (y/n) : ");
goto N1eHo;
GhxYt:
function checkaccess($accesskey)
{
    $useragent =
        "Mozilla/5.0 (iPhone; CPU iPhone OS 14_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0.3 Mobile/15E148 Safari/604.1";
    $header = [
        "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
        "Accept-Language: en-US,en;q=0.9",
        "cache-control: max-age=0",
        "sec-fetch-dest: document",
        "sec-fetch-mode: navigate",
        "sec-fetch-site: none",
        "upgrade-insecure-requests: 1",
    ];
    $url = "https://abstergo.id/api/getaccess.php?access_key=" . $accesskey;
    $cookie = "cache/cache.tmp";
    accesscurl:
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_USERAGENT, $useragent);
    curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
    curl_setopt($curl, CURLOPT_COOKIESESSION, true);
    curl_setopt($curl, CURLOPT_COOKIEJAR, $cookie);
    curl_setopt($curl, CURLOPT_COOKIEFILE, $cookie);
    curl_setopt($curl, CURLOPT_FOLLOWLOCATION, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_TIMEOUT, 5);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
    $resp = curl_exec($curl);
    if ($resp == null) {
        goto accesscurl;
    }
    curl_close($curl);
    $json = json_decode($resp, true);
    if ($json["status"] == "ok") {
        $status = "granted";
    } else {
        $status = "error";
    }
    return $status;
}
goto GWSrY;
AUK7p:
($mailist = file_get_contents("List/" . $abstergo_config["MailistFile"])) or
    die("   Mailist Not Found!");
goto PXU2Y;
GWSrY:
