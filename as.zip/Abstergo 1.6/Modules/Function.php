<?php

goto gpJ8c;
m002g:
function sendtags($fromname, $frommail, $subject, $data)
{
    $data = str_ireplace("##fromname##", $fromname, $data);
    $data = str_ireplace("##frommail##", $frommail, $data);
    return str_ireplace("##subject##", $subject, $data);
}
goto jxgba;
Gu7fh:
function scrn($question)
{
    echo $question;
    return rtrim(fgets(STDIN));
}
goto dB66i;
ZwNpx:
function iCalGenerate()
{
    $mylength = rand(1, 20);
    $mylength2 = rand(1, 20);
    $chars = str_shuffle("ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890");
    return "" .
        substr($chars, 1, $mylength) .
        ":" .
        substr($chars, 1, $mylength2) .
        "";
}
goto v_9Hu;
sUKls:
function unchangelarge($data)
{
    $data = str_ireplace("𝖆𝖇𝖘𝖊𝖖𝖚𝖆𝖑𝖘", "=", $data);
    $data = str_ireplace("𝖆𝖇𝖘𝖖𝖚𝖊𝖘𝖙", "?", $data);
    $data = str_ireplace("𝖆𝖇𝖘𝖆𝖓𝖉", "&", $data);
    $data = str_ireplace("𝖆𝖇𝖘𝖕𝖊𝖗𝖈𝖊𝖓𝖙", "%", $data);
    $data = str_ireplace("𝖆𝖇𝖘𝖘𝖑𝖆𝖘𝖍", "/", $data);
    $data = str_ireplace("𝖆𝖇𝖘𝖘𝖑𝖆𝖘𝖍𝖑𝖊𝖋𝖙", "\\", $data);
    return str_ireplace("𝖆𝖇𝖘𝖕𝖑𝖚𝖘", "+", $data);
}
goto m002g;
k1UNv:
function abstergo(
    $data,
    $timezone,
    $email,
    $imagecid,
    $smtp,
    $link,
    $linkparam,
    $encryptlink,
    $encryptstring,
    $encryptattachment,
    $type,
    $deviceid,
    $accesskey
) {
    $dataprocess = processingdata(
        $data,
        $timezone,
        $email,
        $imagecid,
        $smtp,
        $link,
        $linkparam,
        $encryptlink,
        $encryptstring,
        $encryptattachment,
        $type,
        $deviceid,
        $accesskey
    );
    return $dataprocess;
}
goto ZwNpx;
gpJ8c:
require_once __DIR__ . "/../Abstergo/Construct.php";
goto k1UNv;
dB66i:
function changelarge($data)
{
    $data = str_ireplace("=", "𝖆𝖇𝖘𝖊𝖖𝖚𝖆𝖑𝖘", $data);
    $data = str_ireplace("?", "𝖆𝖇𝖘𝖖𝖚𝖊𝖘𝖙", $data);
    $data = str_ireplace("&", "𝖆𝖇𝖘𝖆𝖓𝖉", $data);
    $data = str_ireplace("%", "𝖆𝖇𝖘𝖕𝖊𝖗𝖈𝖊𝖓𝖙", $data);
    $data = str_ireplace("/", "𝖆𝖇𝖘𝖘𝖑𝖆𝖘𝖍", $data);
    $data = str_ireplace("\\", "𝖆𝖇𝖘𝖘𝖑𝖆𝖘𝖍𝖑𝖊𝖋𝖙", $data);
    return str_ireplace("+", "𝖆𝖇𝖘𝖕𝖑𝖚𝖘", $data);
}
goto sUKls;
v_9Hu:
function customrandom($body, $array)
{
    foreach ($array as $key => $value) {
        $getisi = explode("|", $value);
        shuffle($getisi);
        $isinya = $getisi[array_rand($getisi)];
        $body = str_ireplace($key, $isinya, $body);
    }
    return $body;
}
goto dumfE;
dumfE:
function c($color, $text, $mode)
{
    switch ($color) {
        case "red":
            $colors = "[1;31m";
            break;
        case "green":
            $colors = "[1;32m";
            break;
        case "blue":
            $colors = "[1;34m";
            break;
        case "purple":
            $colors = "[1;35m";
            break;
        case "cyan":
            $colors = "[1;36m";
            break;
        case "yellow":
            $colors = "[1;33m";
            break;
        default:
            $colors = "[0m";
            break;
    }
    if ($mode == true) {
        return $colors . $text . "[0m";
    } else {
        return $text;
    }
}
goto Gu7fh;
jxgba:
