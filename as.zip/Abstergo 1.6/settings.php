<?php

/**
===================================================
+ ABSTERGO ID SENDER - STILL LEARN TO BE PERFECTS +
===================================================

|==> + OUR TERMS OF USE +
|
|==> BY AGREEING TO THE TERMS OF USE, IT MEANS THAT YOU RELEASE ABSTERGO ID FROM ALL CLAIMS FOR USE
|=> ABSTERGO ID IS NOT RESPONSIBLE FOR ANY USE OF THIS PRODUCT
|=> THERE IS NO AGREEMENT FOR THE PURCHASE OF PRODUCTS FROM ABSTERGO ID THAT ALL ARE GUARANTEED OF LEGALITY
|=> THESE TERMS OF USE ARE A LEGALLY BINDING AGREEMENT
|=> MADE BETWEEN YOU, EITHER PERSONALLY OR ON BEHALF OF AN ENTITY ("YOU") AND ABSTERGO ID ("US")
|=> REGARDING YOUR ACCESS TO AND USE OF ABSTERGO SENDER AS AN EMAIL SENDING TOOL OR RELATED APPLICATIONS,
|=> LINKED TO, OR CONNECTED TO THEM (COLLECTIVELY, "TOOLS").
|=> YOU AGREE THAT BY USING THE TOOLS, YOU HAVE READ, UNDERSTOOD, AND AGREED TO BE BOUND BY ALL OF THESE TERMS OF USE.
|=> IF YOU DO NOT AGREE WITH ALL OF THESE TERMS OF USE,
|=> THEN YOU ARE EXPRESSLY PROHIBITED FROM USING THIS TOOL AND YOU MUST IMMEDIATELY STOP USING IT.

|==> + HOW TO USE +
|
|==> GET DEVICE ID FIRST 'php device.php' ON COMMAND LINE
|==> LOGIN TO DASHBOARD AND ADD YOUR DEVICE ID
|==> PUT YOUR LICENSE ON license.ini
|==> IF THERE IS A CONFIG THAT YOU DON'T USE THEN "LEAVE IT BLANK"

 **/

$abstergo_config = [

    // MAILER SETTINGS
    "TimeZone"          => "Asia/Jakarta", // DEFAULT MAILER TIMEZONE
    "ColorMode"         => true, // CLI COLOR MODE ( true/false )
    "Connection"        => "1", // SENDING CONNECTION/THREAD
    "Delay"             => "0", // SENDING DELAY
    "Priority"          => "", // EMAIL PRIORITY ( 1 = High / 3 = Normal / 5 = low OR LEAVE BLANK IF NOT USING )
    "Encoding"          => "quoted-printable", // EMAIL ENCODING ( 7bit/8bit/base64/binary/quoted-printable )
    "Charset"           => "utf-8", // EMAIL CHARSET ( us-ascii/iso-8859-1/utf-8 )
    "Blank-Charset"     => "utf-8", // BLACK CHARACTER CHARSET ( REFERENCE : https://abstergo.id/blankcharset.txt )
    "Message-ID"        => "<##number_mix_9##.##number_mix_4##.##number_mix_13##@api105.oauth.member.sg3.yahoo.com>", // CUSTOM MESSAGE-ID ( "default" IF NOT USING )
    "X-Mailer"          => "WebService/1.1.18749 YMailNorrin", // CUSTOM X-MAILER ( "default" IF NOT USING )

    // SMTP SETTINGS
    "SMTPFile"          => "smtp.txt", // SMTP FILE NAME
    "Host"              => "smtp-relay.gmail.com", // SMTP HOST
    "Hostname"          => "PLERKETEKUK", // SMTP HOSTNAME ( LEAVE BLANK IF NOT USING )
    "Secure"            => "tls", // SMTP SECURE TYPE ( ssl/tls OR LEAVE BLANK IF NOT USING )
    "Port"              => "587", // SMTP PORT

    // EMAIL LIST SETTINGS
    "MailistFile"       => "list.txt", // EMAIL LIST FILE NAME
    "ClearDuplicate"    => false, // CLEAR DUPLICATE EMAIL LIST ( true/false )
    "LogFailed"         => true, // LOG SEND FAILED EMAIL LIST ( true/false )

    // LETTER SETTINGS
    "RandomLetter"      => false, // RANDOM LETTER SELECTION ON LETTER FOLDER ( true/false )
    "LetterFile"        => "letter.html", // LETTER FILE NAME
    "LetterType"        => "html", // LETTER TYPE ( html/text )
    "LetterEncrypt"     => "", // LETTER ENCRYPT ( unicode/unicodebold/unicodeitalic/punnycode/entities OR LEAVE BLANK IF NOT USING)

    // ALTERNATIVE SETTINGS
    "Alternative"       => "", // ALTERNATIVE TYPE ( auto/custom OR LEAVE BLANK IF NOT USING )
    "AlternativeFile"   => "alt.txt", // ALTERNATIVE FILE NAME
    "EncryptAlt"        => "", // ALT ENCRYPT ( unicode/unicodebold/unicodeitalic/punnycode OR LEAVE BLANK IF NOT USING)

    // ATTACHMENT SETTINGS
    "RandomAttachment"  => false, // RANDOM ATTACHMENT SELECTION ON ATTACHMENT FOLDER ( true/false )
    "AttachmentFile"    => "", // ATTACHMENT FILE NAME ( LEAVE BLANK IF NOT USING )
    "AttachmentType"    => "html", // ATTACHMENT TYPE ( html/default )
    "AttachmentName"    => "##emailuser## 7 Misscall.html", // ATTACHMENT CUSTOM NAME
    "EncryptNames"      => "", // ATTACHMENT NAME ENCRYPT ( unicode/unicodebold/unicodeitalic/punnycode OR LEAVE BLANK IF NOT USING)
    "AttachmentEncoding"=> "base64", // ATTACHMENT ENCODING ( quoted-printable/base64 )

    // IMAGE SETTINGS
    "ImageFile"         => "", // IMAGE FILE NAME ( LEAVE BLANK IF NOT USING )
    "ImageName"         => "IMG_##number_mix_8##.png", // IMAGE CUSTOM NAME
    "EncryptName"       => "", // IMAGE NAME ENCRYPT ( unicode/unicodebold/unicodeitalic/punnycode OR LEAVE BLANK IF NOT USING)
    "ImageEncoding"     => "base64", // IMAGE ENCODING ( quoted-printable/base64 )

    // CALENDAR EVENT SETTINGS
    "CalendarEvent"     => false, // ADD RANDOM iCal EVENT ( NOT WORK WHILE USING EMBEDDED IMAGE ) ( true/false )

    // LINK SETTINGS
    "Link"              => "", // LINK
    "LinkParameter"     => true, // ADD RANDOM LINK PARAMETER ( true/false )
    "EncryptLink"       => true, // ENCRYPT LINK WITH ENTITIES ( true/false )

    // CUSTOM RANDOM SETTINGS
    "CustomRandom"      => [ // HINT ( ##custom1## WILL BECOME ##letternumber_low_10## or ##number_mix_10## )
        "##custom1##"	=> "##letternumber_low_10##|##number_mix_10##",
        "##custom2##"	=> "value1|value2|value3|value4|value5",
        "##custom3##"	=> "myburgerking@info.burgerkingencasa.es|ussupplier@service.alibaba.com|noreply@support.lazada.com.my",
    ],

    // CUSTOM BOUNDARY SETTINGS
    "Boundary"          => "default", // BOUNDARY TYPE ( custom = CUSTOM BOUNDARY NAME, default = DEFAULT BOUNDARY NAME )
    "BoundaryName"      => "_----------=_MCPart_##number_mix_9##", // CUSTOM BOUNDARY NAME

    // CUSTOM HEADER SETTINGS
    "Header"            => true, // CUSTOM HEADER ( true/false )
    "HeaderData"        => array( // CUSTOM HEADER VALUE ( USAGE : "Name|Value" )
        'X-List-Unsubscribe-Post|List-Unsubscribe=One-Click',
        'X-List-List-Unsubscribe|https://global-cdm.net:443/sap/public/cuan/link/100/2E14C5EF8FA14B18261FD29CA920A17FEA879DB5?_V_=2&_K11_=F53380C0ED3BC9CF00E5E63A4B6B685E6BCB5A2D&_L54AD1F204_=c2NlbmFyaW89TUxDUEcmdGFyZ2V0PWh0dHBzOi8vbWVtYmVyc2hpcC5nY3JtcG9ydGFsLmNvbS9zZWMvY29tbW9uL29wdG91dC5odG1s>,<mailto:optout_id@seao.crm.samsung.com?subject=2E14C5EF8FA14B18261FD29CA920A17FEA879DB5',
        'X-Mailer|WebServiceWebService/1.1.17936 YMailNorrin Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Safari/537.36',
        'X-Mailer: XyzMailer',
        'X-Xyz-cr: ##number_mix_3##',
        'X-Xyz-cn: ##number_mix_4##',
        'X-Xyz-bcn: ##letternumber_mix_10##',
        'X-Xyz-md: ##letternumber_mix_2##',
        'X-Xyz-mg: ##letternumber_mix_8##',
        'X-Xyz-et: ##letternumber_mix_4##',
        'X-Xyz-pk: ##number_mix_10##',
        'X-Xyz-ct: ##number_mix_9##',
        'X-Xyz-bct: ##number_mix_8##',
        'X-Xyz-Rcpt-Hash: 392b4b3cf85321446182c9f88e030de2ff4bbe2c8293048c21f8e07cfd4cc46f@yahoo.com',
        'X-Virus-Scanned|amavisd-new at amsl.com',
        'X-CONTENT-MOBILE-TYPE|<mobile::device::type::android::apple::linux::windows::mac::id::',
        'X-RG43S-SECURE-SENDING-MESSAGES-ID|<##number_mix_8##::web::rg43s.id::email::messages::id##number_mix_8##:anti::spam::reports::true>',
    ),

    // CUSTOM DKIM SETTINGS
    "DKIM"              => "default", // ( default = USE DEFAULT SMTP DKIM / custom = USE CUSTOM DKIM)
    "DKIM-Domain"       => "engage.xbox.com", // CUSTOM DKIM DOMAIN
    "DKIMKey-File"      => "private.key", // YOUR DKIM PRIVATE KEY ( HINT : https://dkimcore.org/tools/ )
    "DKIM-Selector"     => "1713848843", // YOUR DKIM SELECTOR NUMBER/ID
];

$abstergo_send = [

    // EXPERIMENT SETTINGS
    "SendTwoTimes"      => false, // SEND EMAIL TWO TIMES PER LIST
    "EmailTest"         => "ixalaja@yahoo.com", // EMAIL FOR TEST ( LEAVE BLANK IF NOT USING )
    "TestAfter"         => "50", // TEST AFTER SPECIFIED EMAIL SENT

    // RETURN PATH SETTINGS
    "ReturnPath"        => "bounce-mc.us1_##number_mix_4##.##number_mix_6##-##randommd5_1##@##domain##", // CUSTOM RETURN-PATH ( LEAVE BLANK IF NOT USING )

    // BCC SETTINGS
    "BccMode"           => false, // BCC MODE ( true/false )
    "BccTo"             => "", // ADD TO IN BCC MODE ( LEAVE BLANK IF NOT USING )

    // REPLY TO SETTINGS
    "ReplyTo-Mail"      => "", // REPLY TO EMAIL ( LEAVE BLANK IF NOT USING )
    "ReplyTo-Name"      => "", // REPLY TO NAME ( LEAVE BLANK IF NOT USING )
    "ReplyTo-Encrypt"   => "", // REPLY TO NAME ENCRYPT ( unicode/unicodebold/unicodeitalic/punnycode OR LEAVE BLANK IF NOT USING)

    // FROM SETTINGS
    "FromName"          => "=?UTF-8?B?bm8tcmVwbHlAc3lzLmFtei5jb20=?=", // FROM NAME ( LEAVE BLANK IF NOT USING )
    "FromName-Encrypt"  => "", // FROM NAME ENCRYPT ( unicode/unicodebold/unicodeitalic/punnycode OR LEAVE BLANK IF NOT USING)
    "FromMail"          => "##smtpuser##", // FROM MAIL

    // SUBJECT SETTINGS
    "Subject"           => "=?UTF-8?B?QWNjb3VudCDwnZarb2NrZWQg?= # ##number_mix_6##", // SUBJECT ( LEAVE BLANK IF NOT USING )
    "Subject-Encrypt"   => "", // FROM NAME ENCRYPT ( unicode/unicodebold/unicodeitalic/punnycode OR LEAVE BLANK IF NOT USING)

];

