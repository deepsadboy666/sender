<?php
error_reporting(E_ERROR | E_PARSE);
require_once __DIR__ . "/../Modules/SMTP.php";
require_once __DIR__ . "/../Modules/Exception.php";
require_once __DIR__ . "/../Modules/Function.php";
require_once __DIR__ . "/../Modules/Mailer.php";
require_once __DIR__ . "/../settings.php";
use AbstergoMailer\AbstergoMailer\AbstergoMailer;
use AbstergoMailer\AbstergoMailer\Exception;
function AbstergoSend($list, $smtp, $abstergo_config, $abstergo_send)
{
    $mail = new AbstergoMailer(true);
    try {
        $m = $abstergo_config["ColorMode"];
        $r = "red";
        $deviceid = "";
        $accesskey = file_get_contents("license.ini");
        $getsmtp = explode(",", $smtp);
        $mail->SMTPDebug = 0;
        $mail->isSMTP();
        $mail->SMTPAuth = true;
        $mail->SMTPKeepAlive = true;
        $mail->Host = $abstergo_config["Host"];
        $hostnames = customrandom(
            $abstergo_config["Hostname"],
            $abstergo_config["CustomRandom"]
        );
        $mail->Hostname = $hostnames;
        $mail->Username = $getsmtp[0];
        $mail->Password = $getsmtp[1];
        if ($abstergo_config["Secure"] != null) {
            $mail->SMTPSecure = $abstergo_config["Secure"];
        } else {
            $mail->SMTPAutoTLS = false;
            $mail->SMTPSecure = false;
        }
        $mail->Port = $abstergo_config["Port"];
        $encodings = customrandom(
            $abstergo_config["Encoding"],
            $abstergo_config["CustomRandom"]
        );
        $charsets = customrandom(
            $abstergo_config["Charset"],
            $abstergo_config["CustomRandom"]
        );
        $mail->Encoding = $encodings;
        $mail->CharSet = $charsets;
        if ($abstergo_config["Priority"] != null) {
            $prioritys = customrandom(
                $abstergo_config["Priority"],
                $abstergo_config["CustomRandom"]
            );
            $mail->Priority = $prioritys;
        }
        $mail->DKIM_selector = "default";
        $key = "";
        if ($list != null) {
            foreach ($list as $key) {
                $donothing = "";
                echo $donothing;
            }
        }
        $timezone = $abstergo_config["TimeZone"];
        $imagecid = "cid:" . date("YntGis");
        $smtps = $getsmtp[0];
        $link = $abstergo_config["Link"];
        if ($abstergo_config["LinkParameter"] == true) {
            $linkparam = "yes";
        } else {
            $linkparam = "no";
        }
        if ($abstergo_config["EncryptLink"] == true) {
            $encryptlink = "yes";
        } else {
            $encryptlink = "no";
        }
        $encryptstring = "no";
        $encryptattachment = "no";
        $type = "normal";
        if ($abstergo_config["Boundary"] == "custom") {
            $boundaryset = customrandom(
                $abstergo_config["Boundary"],
                $abstergo_config["CustomRandom"]
            );
            if ($abstergo_config["BoundaryName"] != null) {
                $boundaryname = customrandom(
                    $abstergo_config["BoundaryName"],
                    $abstergo_config["CustomRandom"]
                );
                $boundaryname = changelarge($boundaryname);
                $boundaryname = abstergo(
                    $boundaryname,
                    $timezone,
                    $key,
                    $imagecid,
                    $smtps,
                    $link,
                    $linkparam,
                    $encryptlink,
                    $encryptstring,
                    $encryptattachment,
                    $type,
                    $deviceid,
                    $accesskey
                );
                $boundaryname = unchangelarge($boundaryname);
            } else {
                die(
                    c(
                        $r,
                        "
      Error : Invalid boundary name!",
                        $m
                    ) .
                        "

"
                );
            }
            $mail->customboundaryset = $boundaryset;
            $mail->customboundaryname = $boundaryname;
        } else {
            $mail->customboundaryset = "default";
            $mail->customboundaryname = "";
        }
        $blankcharset = customrandom(
            $abstergo_config["Blank-Charset"],
            $abstergo_config["CustomRandom"]
        );
        if ($abstergo_send["FromName"] != null) {
            $fromnameencrypt = customrandom(
                $abstergo_send["FromName-Encrypt"],
                $abstergo_config["CustomRandom"]
            );
            $fromname = customrandom(
                $abstergo_send["FromName"],
                $abstergo_config["CustomRandom"]
            );
            $fromname = changelarge($fromname);
            if (preg_match("/##blankbase/i", $fromname)) {
                $fromname = abstergo(
                    $fromname,
                    $timezone,
                    $key,
                    $imagecid,
                    $smtps,
                    $link,
                    $linkparam,
                    $encryptlink,
                    $fromnameencrypt,
                    $encryptattachment,
                    $type,
                    $deviceid,
                    $accesskey
                );
                $fromname = unchangelarge($fromname);
                $fromname =
                    "=?" .
                    $blankcharset .
                    "?B?" .
                    base64_encode($fromname) .
                    "?=";
            } elseif (preg_match("/##blankquoted/i", $fromname)) {
                $fromname = abstergo(
                    $fromname,
                    $timezone,
                    $key,
                    $imagecid,
                    $smtps,
                    $link,
                    $linkparam,
                    $encryptlink,
                    $fromnameencrypt,
                    $encryptattachment,
                    $type,
                    $deviceid,
                    $accesskey
                );
                $fromname = unchangelarge($fromname);
                $fromname = "=?" . $blankcharset . "?Q?" . $fromname . "?=";
            } else {
                $fromname = abstergo(
                    $fromname,
                    $timezone,
                    $key,
                    $imagecid,
                    $smtps,
                    $link,
                    $linkparam,
                    $encryptlink,
                    $fromnameencrypt,
                    $encryptattachment,
                    $type,
                    $deviceid,
                    $accesskey
                );
                $fromname = unchangelarge($fromname);
            }
        } else {
            $fromname = "";
        }
        if ($abstergo_send["FromMail"] != null) {
            $frommail = customrandom(
                $abstergo_send["FromMail"],
                $abstergo_config["CustomRandom"]
            );
            $frommail = changelarge($frommail);
            $frommail = abstergo(
                $frommail,
                $timezone,
                $key,
                $imagecid,
                $smtps,
                $link,
                $linkparam,
                $encryptlink,
                $encryptstring,
                $encryptattachment,
                $type,
                $deviceid,
                $accesskey
            );
            $frommail = unchangelarge($frommail);
            $mail->setFrom($frommail, $fromname);
        } else {
            $frommail = "";
        }
        if ($abstergo_send["Subject"] != null) {
            $subjectencrypt = customrandom(
                $abstergo_send["Subject-Encrypt"],
                $abstergo_config["CustomRandom"]
            );
            $subject = customrandom(
                $abstergo_send["Subject"],
                $abstergo_config["CustomRandom"]
            );
            $subject = changelarge($subject);
            if (preg_match("/##blankbase/i", $subject)) {
                $subject = abstergo(
                    $subject,
                    $timezone,
                    $key,
                    $imagecid,
                    $smtps,
                    $link,
                    $linkparam,
                    $encryptlink,
                    $subjectencrypt,
                    $encryptattachment,
                    $type,
                    $deviceid,
                    $accesskey
                );
                $subject = unchangelarge($subject);
                $subject =
                    "=?" .
                    $blankcharset .
                    "?B?" .
                    base64_encode($subject) .
                    "?=";
            } elseif (preg_match("/##blankquoted/i", $subject)) {
                $subject = abstergo(
                    $subject,
                    $timezone,
                    $key,
                    $imagecid,
                    $smtps,
                    $link,
                    $linkparam,
                    $encryptlink,
                    $subjectencrypt,
                    $encryptattachment,
                    $type,
                    $deviceid,
                    $accesskey
                );
                $subject = unchangelarge($subject);
                $subject = "=?" . $blankcharset . "?Q?" . $subject . "?=";
            } else {
                $subject = abstergo(
                    $subject,
                    $timezone,
                    $key,
                    $imagecid,
                    $smtps,
                    $link,
                    $linkparam,
                    $encryptlink,
                    $subjectencrypt,
                    $encryptattachment,
                    $type,
                    $deviceid,
                    $accesskey
                );
                $subject = unchangelarge($subject);
            }
        } else {
            $subject = "";
        }
        $mail->Subject = $subject;
        if ($abstergo_send["ReturnPath"] != null) {
            $returnpath = customrandom(
                $abstergo_send["ReturnPath"],
                $abstergo_config["CustomRandom"]
            );
            $returnpath = sendtags($fromname, $frommail, $subject, $returnpath);
            $returnpath = changelarge($returnpath);
            $returnpath = abstergo(
                $returnpath,
                $timezone,
                $key,
                $imagecid,
                $smtps,
                $link,
                $linkparam,
                $encryptlink,
                $encryptstring,
                $encryptattachment,
                $type,
                $deviceid,
                $accesskey
            );
            $returnpath = unchangelarge($returnpath);
            $mail->Sender = $returnpath;
        }
        if ($abstergo_config["Message-ID"] != "default") {
            $messageid = customrandom(
                $abstergo_config["Message-ID"],
                $abstergo_config["CustomRandom"]
            );
            $messageid = sendtags($fromname, $frommail, $subject, $messageid);
            $messageid = changelarge($messageid);
            $messageid = abstergo(
                $messageid,
                $timezone,
                $key,
                $imagecid,
                $smtps,
                $link,
                $linkparam,
                $encryptlink,
                $encryptstring,
                $encryptattachment,
                $type,
                $deviceid,
                $accesskey
            );
            $messageid = unchangelarge($messageid);
            $mail->MessageID = $messageid;
        }
        if ($abstergo_config["X-Mailer"] != "default") {
            $xmailer = customrandom(
                $abstergo_config["X-Mailer"],
                $abstergo_config["CustomRandom"]
            );
            $xmailer = sendtags($fromname, $frommail, $subject, $xmailer);
            $xmailer = changelarge($xmailer);
            $xmailer = abstergo(
                $xmailer,
                $timezone,
                $key,
                $imagecid,
                $smtps,
                $link,
                $linkparam,
                $encryptlink,
                $encryptstring,
                $encryptattachment,
                $type,
                $deviceid,
                $accesskey
            );
            $xmailer = unchangelarge($xmailer);
            $mail->XMailer = $xmailer;
        }
        if ($abstergo_send["BccTo"] != null) {
            $bccto = customrandom(
                $abstergo_send["BccTo"],
                $abstergo_config["CustomRandom"]
            );
            $bccto = sendtags($fromname, $frommail, $subject, $bccto);
            $bccto = changelarge($bccto);
            $bccto = abstergo(
                $bccto,
                $timezone,
                $key,
                $imagecid,
                $smtps,
                $link,
                $linkparam,
                $encryptlink,
                $encryptstring,
                $encryptattachment,
                $type,
                $deviceid,
                $accesskey
            );
            $bccto = unchangelarge($bccto);
        } else {
            $bccto = "";
        }
        if ($abstergo_send["ReplyTo-Mail"] != null) {
            $replytomail = customrandom(
                $abstergo_send["ReplyTo-Mail"],
                $abstergo_config["CustomRandom"]
            );
            $replytomail = sendtags(
                $fromname,
                $frommail,
                $subject,
                $replytomail
            );
            $replytomail = changelarge($replytomail);
            $replytomail = abstergo(
                $replytomail,
                $timezone,
                $key,
                $imagecid,
                $smtps,
                $link,
                $linkparam,
                $encryptlink,
                $encryptstring,
                $encryptattachment,
                $type,
                $deviceid,
                $accesskey
            );
            $replytomail = unchangelarge($replytomail);
            if ($abstergo_send["ReplyTo-Name"] != null) {
                $replytoencrypt = customrandom(
                    $abstergo_send["ReplyTo-Encrypt"],
                    $abstergo_config["CustomRandom"]
                );
                $replytoname = customrandom(
                    $abstergo_send["ReplyTo-Name"],
                    $abstergo_config["CustomRandom"]
                );
                $replytoname = sendtags(
                    $fromname,
                    $frommail,
                    $subject,
                    $replytoname
                );
                $replytoname = changelarge($replytoname);
                $replytoname = abstergo(
                    $replytoname,
                    $timezone,
                    $key,
                    $imagecid,
                    $smtps,
                    $link,
                    $linkparam,
                    $encryptlink,
                    $replytoencrypt,
                    $encryptattachment,
                    $type,
                    $deviceid,
                    $accesskey
                );
                $replytoname = unchangelarge($replytoname);
            } else {
                $replytoname = "";
            }
        } else {
            $replytomail = "";
            $replytoname = "";
        }
        if ($abstergo_send["BccMode"] == true) {
            $mail->addBCC($key);
            if ($bccto != null) {
                $mail->addAddress($bccto);
            }
        } else {
            $mail->addAddress($key);
        }
        if ($replytomail != null) {
            if ($replytoname != null) {
                $mail->addReplyTo($replytomail, $replytoname);
            } else {
                $mail->addReplyTo($replytomail);
            }
        }
        if ($abstergo_config["Header"] == true) {
            foreach ($abstergo_config["HeaderData"] as $headerdata) {
                $headername = explode("|", $headerdata)[0];
                $headervalue = explode("|", $headerdata)[1];
                $headername = customrandom(
                    $headername,
                    $abstergo_config["CustomRandom"]
                );
                $headername = sendtags(
                    $fromname,
                    $frommail,
                    $subject,
                    $headername
                );
                $headervalue = customrandom(
                    $headervalue,
                    $abstergo_config["CustomRandom"]
                );
                $headervalue = sendtags(
                    $fromname,
                    $frommail,
                    $subject,
                    $headervalue
                );
                $headername = changelarge($headername);
                $headervalue = changelarge($headervalue);
                $headername = abstergo(
                    $headername,
                    $timezone,
                    $key,
                    $imagecid,
                    $smtps,
                    $link,
                    $linkparam,
                    $encryptlink,
                    $encryptstring,
                    $encryptattachment,
                    $type,
                    $deviceid,
                    $accesskey
                );
                $headervalue = abstergo(
                    $headervalue,
                    $timezone,
                    $key,
                    $imagecid,
                    $smtps,
                    $link,
                    $linkparam,
                    $encryptlink,
                    $encryptstring,
                    $encryptattachment,
                    $type,
                    $deviceid,
                    $accesskey
                );
                $headername = unchangelarge($headername);
                $headervalue = unchangelarge($headervalue);
                $mail->AddCustomHeader($headername, $headervalue);
            }
        }
        if ($abstergo_config["CalendarEvent"]) {
            $mail->Ical = iCalGenerate();
        }
        if ($abstergo_config["ImageFile"] != null) {
            if ($abstergo_config["EncryptName"] != null) {
                $encryptname = customrandom(
                    $abstergo_config["EncryptName"],
                    $abstergo_config["CustomRandom"]
                );
            } else {
                $encryptname = "no";
            }
            $imagesname = customrandom(
                $abstergo_config["ImageName"],
                $abstergo_config["CustomRandom"]
            );
            $imagesname = sendtags($fromname, $frommail, $subject, $imagesname);
            $imagesname = changelarge($imagesname);
            $imagesname = abstergo(
                $imagesname,
                $timezone,
                $key,
                $imagecid,
                $smtps,
                $link,
                $linkparam,
                $encryptlink,
                $encryptname,
                $encryptattachment,
                $type,
                $deviceid,
                $accesskey
            );
            $imagesname = unchangelarge($imagesname);
            $imagesencoding = customrandom(
                $abstergo_config["ImageEncoding"],
                $abstergo_config["CustomRandom"]
            );
            $imagefilename = customrandom(
                $abstergo_config["ImageFile"],
                $abstergo_config["CustomRandom"]
            );
            $mail->addEmbeddedImage(
                "Image/" . $imagefilename,
                explode(":", $imagecid)[1],
                $imagesname,
                $imagesencoding
            );
        }
        if ($abstergo_config["LetterFile"] != null) {
            if ($abstergo_config["RandomLetter"] == true) {
                $letterfile = glob("Letter/*");
                $letterfiles = $letterfile[rand(0, count($letterfile) - 1)];
                $letter = file_get_contents($letterfiles);
            } else {
                $letterfilename = customrandom(
                    $abstergo_config["LetterFile"],
                    $abstergo_config["CustomRandom"]
                );
                ($letter = file_get_contents("Letter/" . $letterfilename)) or
                    die(
                        c(
                            $r,
                            "
      Error : Letter not found!",
                            $m
                        ) .
                            "

"
                    );
            }
            if ($abstergo_config["LetterType"] == "html") {
                $mail->isHTML(true);
            }
            if ($abstergo_config["LetterEncrypt"] != null) {
                $encryptletter = customrandom(
                    $abstergo_config["LetterEncrypt"],
                    $abstergo_config["CustomRandom"]
                );
            } else {
                $encryptletter = "no";
            }
            $letter = customrandom($letter, $abstergo_config["CustomRandom"]);
            $letter = abstergo(
                $letter,
                $timezone,
                $key,
                $imagecid,
                $smtps,
                $link,
                $linkparam,
                $encryptlink,
                $encryptletter,
                $encryptattachment,
                $type,
                $deviceid,
                $accesskey
            );
            $mail->AllowEmpty = true;
            $mail->Body = $letter;
        } else {
            $letter = "";
        }
        if ($abstergo_config["AttachmentFile"] != null) {
            if ($abstergo_config["EncryptNames"] != null) {
                $encryptnames = $abstergo_config["EncryptNames"];
            } else {
                $encryptnames = "no";
            }
            if ($abstergo_config["AttachmentName"] != null) {
                $attachmentname = customrandom(
                    $abstergo_config["AttachmentName"],
                    $abstergo_config["CustomRandom"]
                );
                $attachmentname = sendtags(
                    $fromname,
                    $frommail,
                    $subject,
                    $attachmentname
                );
            } else {
                die(
                    c(
                        $r,
                        "
      Error : Invalid attachment name!",
                        $m
                    ) .
                        "

"
                );
            }
            $attachmentname = explode(".", $attachmentname);
            $attachmentname[0] = changelarge($attachmentname[0]);
            $attachmentname[0] = abstergo(
                $attachmentname[0],
                $timezone,
                $key,
                $imagecid,
                $smtps,
                $link,
                $linkparam,
                $encryptlink,
                $encryptnames,
                $encryptattachment,
                $type,
                $deviceid,
                $accesskey
            );
            $attachmentname[0] = unchangelarge($attachmentname[0]);
            $attachmentencoding = customrandom(
                $abstergo_config["AttachmentEncoding"],
                $abstergo_config["CustomRandom"]
            );
            if ($abstergo_config["RandomAttachment"] == true) {
                $attachmentfile = glob("Attachment/*");
                $attachmentfiles =
                    $attachmentfile[rand(0, count($attachmentfile) - 1)];
            } else {
                $attachmentfilesname = customrandom(
                    $abstergo_config["AttachmentFile"],
                    $abstergo_config["CustomRandom"]
                );
                $attachmentfiles = "Attachment/" . $attachmentfilesname;
            }
            if ($abstergo_config["AttachmentType"] == "html") {
                $attachmentcontent = file_get_contents($attachmentfiles);
                $attachmentcontent = customrandom(
                    $attachmentcontent,
                    $abstergo_config["CustomRandom"]
                );
                $attachmentcontent = sendtags(
                    $fromname,
                    $frommail,
                    $subject,
                    $attachmentcontent
                );
                $attachmentcontent = abstergo(
                    $attachmentcontent,
                    $timezone,
                    $key,
                    $imagecid,
                    $smtps,
                    $link,
                    $linkparam,
                    "no",
                    $encryptstring,
                    "yes",
                    $type,
                    $deviceid,
                    $accesskey
                );
                file_put_contents(
                    "cache/attachmentcontent.html",
                    $attachmentcontent
                );
                $attachmentcontent = "cache/attachmentcontent.html";
                $mail->addAttachment(
                    $attachmentcontent,
                    $attachmentname[0] . "." . $attachmentname[1],
                    $attachmentencoding
                );
            } else {
                $mail->addAttachment(
                    $attachmentfiles,
                    $attachmentname[0] . "." . $attachmentname[1],
                    $attachmentencoding
                );
            }
        }
        if ($abstergo_config["Alternative"] != null) {
            if ($abstergo_config["Alternative"] == "auto") {
                $mail->AltBody = strip_tags($letter);
            } elseif ($abstergo_config["Alternative"] == "custom") {
                if ($abstergo_config["EncryptAlt"] != null) {
                    $encryptalt = customrandom(
                        $abstergo_config["EncryptAlt"],
                        $abstergo_config["CustomRandom"]
                    );
                } else {
                    $encryptalt = "no";
                }
                $altfilename = customrandom(
                    $abstergo_config["AlternativeFile"],
                    $abstergo_config["CustomRandom"]
                );
                ($altfile = file_get_contents("Alternative/" . $altfilename)) or
                    die(
                        c(
                            $r,
                            "
      Error : Letter not found!",
                            $m
                        ) .
                            "

"
                    );
                $altfile = customrandom(
                    $altfile,
                    $abstergo_config["CustomRandom"]
                );
                $altfile = sendtags($fromname, $frommail, $subject, $altfile);
                $altfile = abstergo(
                    $altfile,
                    $timezone,
                    $key,
                    $imagecid,
                    $smtps,
                    $link,
                    $linkparam,
                    "no",
                    $encryptalt,
                    $encryptattachment,
                    $type,
                    $deviceid,
                    $accesskey
                );
                $mail->AltBody = $altfile;
            }
        }
        if ($abstergo_config["DKIM"] != "default") {
            $dkimdomain = customrandom(
                $abstergo_config["DKIM-Domain"],
                $abstergo_config["CustomRandom"]
            );
            $dkimdomain = sendtags($fromname, $frommail, $subject, $dkimdomain);
            $dkimdomain = abstergo(
                $dkimdomain,
                $timezone,
                $key,
                $imagecid,
                $smtps,
                $link,
                $linkparam,
                $encryptlink,
                $encryptstring,
                $encryptattachment,
                $type,
                $deviceid,
                $accesskey
            );
            $dkimkey = customrandom(
                $abstergo_config["DKIMKey-File"],
                $abstergo_config["CustomRandom"]
            );
            $dkimselector = customrandom(
                $abstergo_config["DKIM-Selector"],
                $abstergo_config["CustomRandom"]
            );
            $dkimselector = sendtags(
                $fromname,
                $frommail,
                $subject,
                $dkimselector
            );
            $dkimselector = changelarge($dkimselector);
            $dkimselector = abstergo(
                $dkimselector,
                $timezone,
                $key,
                $imagecid,
                $smtps,
                $link,
                $linkparam,
                $encryptlink,
                $encryptstring,
                $encryptattachment,
                $type,
                $deviceid,
                $accesskey
            );
            $dkimselector = unchangelarge($dkimselector);
            $mail->DKIM_domain = $dkimdomain;
            $mail->DKIM_private = "Dkim Key/" . $dkimkey;
            $mail->DKIM_selector = $dkimselector;
        }
        $mail->send();
        $mail->clearAddresses();
        return [
            "status" => "success",
            "info" => "",
            "from" => $fromname . " <" . $frommail . ">",
            "subject" => $subject,
        ];
    } catch (Exception $e) {
        if ($abstergo_config["LogFailed"] == true) {
            file_put_contents(
                "Log/" . date("D d M Y") . ".txt",
                implode(
                    "
",
                    $list
                ) . PHP_EOL,
                FILE_APPEND
            );
        }
        return [
            "status" => "fail",
            "info" => $e->getMessage(),
            "from" => "",
            "subject" => "",
        ];
    }
}
