<?php

goto TtQvg;
ontjL:
function processingdata(
    $data,
    $timezone,
    $email,
    $imagecid,
    $smtp,
    $link,
    $linkparam,
    $encryptlink,
    $encryptstring,
    $encryptattachment,
    $type,
    $deviceid,
    $accesskey
) {
    date_default_timezone_set($timezone);
    if ($data == "no") {
        return "";
    } else {
        $link = tagsgen($link, $email, $smtp);
        $link = random($link);
        $data = str_ireplace("##imagecid##", $imagecid, $data);
        if ($linkparam == "yes") {
            $link = formatter($link, "addparam");
        }
        if ($encryptlink == "yes") {
            $link = formatter($link, "encryptlink");
        }
        $data = str_ireplace("##link##", $link, $data);
        $data = tagsgen($data, $email, $smtp);
        $data = random($data);
        if ($encryptstring == "unicode") {
            $data = formatter($data, "unicode");
        } elseif ($encryptstring == "unicodebold") {
            $data = formatter($data, "unicodebold");
        } elseif ($encryptstring == "unicodeitalic") {
            $data = formatter($data, "unicodeitalic");
        } elseif ($encryptstring == "punnycode") {
            $data = formatter($data, "punnycode");
        } elseif ($encryptstring == "entities") {
            $data = formatter($data, "entities");
        }
        if ($encryptattachment == "yes") {
            $data = formatter($data, "encryptattachment");
        }
        return $data;
    }
}
goto AS3LR;
AS3LR:
function tagsgen($datas, $email, $smtp)
{
    $datas = str_ireplace(
        "##randomdomain##",
        getrandom("randomdomain"),
        $datas
    );
    $datas = str_ireplace("##date##", date("D d M Y"), $datas);
    $datas = str_ireplace("##time##", date("h:i a"), $datas);
    $datas = str_ireplace("##datetime##", date("D d M Y h:i a"), $datas);
    $datas = str_ireplace(
        "##datetomorrow##",
        date("D d M Y", strtotime("+1 days")),
        $datas
    );
    $datas = str_ireplace(
        "##datetimetomorrow##",
        date("D d M Y h:i a", strtotime("+1 days")),
        $datas
    );
    $datas = str_ireplace(
        "##dateyesterday##",
        date("D d M Y", strtotime("-1 days")),
        $datas
    );
    $datas = str_ireplace(
        "##datetimeyesterday##",
        date("D d M Y h:i a", strtotime("-1 days")),
        $datas
    );
    $datas = str_ireplace("##email##", $email, $datas);
    $datas = str_ireplace(
        "##emailuser",
        formatter($email, "emailuser"),
        $datas
    );
    $datas = str_ireplace(
        "##emaildomain##",
        formatter($email, "emaildomain"),
        $datas
    );
    $datas = str_ireplace(
        "##emaildomainfull##",
        formatter($email, "emaildomainfull"),
        $datas
    );
    $datas = str_ireplace(
        "##emailcencored##",
        formatter($email, "emailcencored"),
        $datas
    );
    $datas = str_ireplace("##emailbase64##", base64_encode($email), $datas);
    $datas = str_ireplace("##emailmd5##", md5($email), $datas);
    $datas = str_ireplace("##useragent##", getrandom("useragent"), $datas);
    $datas = str_ireplace("##ip##", getrandom("ip"), $datas);
    $datas = str_ireplace("##pcos##", getrandom("pcos"), $datas);
    $datas = str_ireplace("##pcbrowser##", getrandom("pcbrowser"), $datas);
    $datas = str_ireplace(
        "##androiddevice##",
        getrandom("androiddevice"),
        $datas
    );
    $datas = str_ireplace("##androidos##", getrandom("androidos"), $datas);
    $datas = str_ireplace(
        "##androidbrowser##",
        getrandom("androidbrowser"),
        $datas
    );
    $datas = str_ireplace("##appleapps##", getrandom("appleapps"), $datas);
    $datas = str_ireplace("##applepc##", getrandom("applepc"), $datas);
    $datas = str_ireplace("##applephones##", getrandom("applephones"), $datas);
    $datas = str_ireplace("##ios##", getrandom("ios"), $datas);
    $datas = str_ireplace("##appletab##", getrandom("appletab"), $datas);
    $datas = str_ireplace("##browser##", getrandom("browser"), $datas);
    $datas = str_ireplace("##country##", getrandom("country"), $datas);
    $datas = str_ireplace("##city##", getrandom("city"), $datas);
    $datas = str_ireplace("##countrycity##", getrandom("countrycity"), $datas);
    $datas = str_ireplace("##domain##", explode("@", $smtp)[1], $datas);
    $datas = str_ireplace("##smtpuser##", $smtp, $datas);
    $datas = str_ireplace("##randomname##", generatename("name"), $datas);
    $datas = str_ireplace("##randomemail##", generatename("email"), $datas);
    $datas = str_ireplace("##blankbase1##", getrandom("blank1"), $datas);
    $datas = str_ireplace("##blankbase2##", getrandom("blank2"), $datas);
    $datas = str_ireplace("##blankbase3##", getrandom("blank3"), $datas);
    $datas = str_ireplace("##blankbase4##", getrandom("blank4"), $datas);
    $datas = str_ireplace("##blankbase5##", getrandom("blank5"), $datas);
    $datas = str_ireplace("##blankbase6##", getrandom("blank6"), $datas);
    $datas = str_ireplace("##blankbase7##", getrandom("blank7"), $datas);
    $datas = str_ireplace("##blankbase8##", getrandom("blank8"), $datas);
    $datas = str_ireplace("##blankbase9##", getrandom("blank9"), $datas);
    $datas = str_ireplace("##blankbase10##", getrandom("blank10"), $datas);
    $datas = str_ireplace("##blankquoted1##", getrandom("blankq1"), $datas);
    $datas = str_ireplace("##blankquoted2##", getrandom("blankq2"), $datas);
    $datas = str_ireplace("##blankquoted3##", getrandom("blankq3"), $datas);
    $datas = str_ireplace("##blankquoted4##", getrandom("blankq4"), $datas);
    $datas = str_ireplace("##blankquoted5##", getrandom("blankq5"), $datas);
    $datas = str_ireplace("##blankquoted6##", getrandom("blankq6"), $datas);
    $datas = str_ireplace("##blankquoted7##", getrandom("blankq7"), $datas);
    $datas = str_ireplace("##blankquoted8##", getrandom("blankq8"), $datas);
    $datas = str_ireplace("##blankquoted9##", getrandom("blankq9"), $datas);
    $datas = str_ireplace("##blankquoted10##", getrandom("blankq10"), $datas);
    $datas = str_ireplace("##blankletter1##", getrandom("blank1"), $datas);
    $datas = str_ireplace("##blankletter2##", getrandom("blank2"), $datas);
    $datas = str_ireplace("##blankletter3##", getrandom("blank3"), $datas);
    $datas = str_ireplace("##blankletter4##", getrandom("blank4"), $datas);
    $datas = str_ireplace("##blankletter5##", getrandom("blank5"), $datas);
    $datas = str_ireplace("##blankletter6##", getrandom("blank6"), $datas);
    $datas = str_ireplace("##blankletter7##", getrandom("blank7"), $datas);
    $datas = str_ireplace("##blankletter8##", getrandom("blank8"), $datas);
    $datas = str_ireplace("##blankletter9##", getrandom("blank9"), $datas);
    $datas = str_ireplace("##blankletter10##", getrandom("blank10"), $datas);
    $datas = str_ireplace("##randommd5_1##", getrandom("md51"), $datas);
    $datas = str_ireplace("##randommd5_2##", getrandom("md52"), $datas);
    $datas = str_ireplace("##randommd5_3##", getrandom("md53"), $datas);
    $datas = str_ireplace("##randommd5_4##", getrandom("md54"), $datas);
    $datas = str_ireplace("##randommd5_5##", getrandom("md55"), $datas);
    $datas = str_ireplace("##randommd5_6##", getrandom("md56"), $datas);
    $datas = str_ireplace("##randommd5_7##", getrandom("md57"), $datas);
    $datas = str_ireplace("##randommd5_8##", getrandom("md58"), $datas);
    $datas = str_ireplace("##randommd5_9##", getrandom("md59"), $datas);
    $datas = str_ireplace("##randommd5_10##", getrandom("md510"), $datas);
    return $datas;
}
goto o45kd;
XYfl6:
require_once "Construct_Skeleton.php";
goto ontjL;
YKBP1:
set_time_limit(0);
goto XYfl6;
TtQvg:
error_reporting(0);
goto YKBP1;
o45kd:
