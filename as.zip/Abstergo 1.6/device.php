<?php

goto S4Suu;
IHZiV:
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
goto q9NDN;
aYVWL:
curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
goto IHZiV;
M0Ttp:
echo c(
    "red",
    "
   PLEASE ADD YOUR DEVICE ID TO YOUR MEMBER DASHBOARD!

",
    true
);
goto wLXYY;
bblLz:
curl_setopt($curl, CURLOPT_URL, $url);
goto o3d0u;
SSPZH:
$curl = curl_init($url);
goto bblLz;
clItC:
echo c(
    "cyan",
    "
   YOUR DEVICE ID => " .
        $deviceid .
        "
",
    true
);
goto M0Ttp;
S4Suu:
require_once "Modules/Function.php";
goto GUa_V;
q9NDN:
$deviceid = strtoupper(md5(curl_exec($curl)));
goto clItC;
GUa_V:
$url = "https://ipecho.net/plain";
goto SSPZH;
o3d0u:
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
goto aYVWL;
wLXYY: